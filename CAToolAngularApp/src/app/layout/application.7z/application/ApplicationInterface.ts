export interface IApplication{

    applicationId:number;
    applicationName:String;
    applicationDescription:String;
    applicationList: String;
    cloudable: String;
    migrationMethod: String;
    cloudProvider: String;
    
}