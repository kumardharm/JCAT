export class Question{
    questionId:number;
    questionText:String;
    questionType : String;
    questionDisplayOrder : number;
    numberOfOption : number;
     
}