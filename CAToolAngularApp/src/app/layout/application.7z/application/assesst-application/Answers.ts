export class Answers{
    answerId : number;
    applicationId : number;
    questionId : number;
    answerText : String;
    cloudAbility : number;
    createdBy : String;
    cteatedTime : Date;
    modifiedBy : String;
    modifiedTime : Date;
}