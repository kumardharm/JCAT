  import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportApplicationRoutingModule } from './import-application-routing.module';
@NgModule({
  imports: [
    CommonModule,ImportApplicationRoutingModule
  ],
  declarations: []
})
export class ImportApplicationModule { }
