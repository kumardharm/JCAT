package com.cg.jcat.api.service;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cg.jcat.api.dao.AssessmentDao;
import com.cg.jcat.api.dao.DTCloudableRuleDao;
import com.cg.jcat.api.dao.DTCloudableRuleModel;
import com.cg.jcat.api.dao.DTMigrationModel;
import com.cg.jcat.api.dao.DTMigrationRuleDao;
import com.cg.jcat.api.dao.DTMigrationRuleModel;
import com.cg.jcat.api.dao.DTProviderRuleDao;
import com.cg.jcat.api.dao.DTProviderRuleModel;
import com.cg.jcat.api.dao.DTProvidersModel;
import com.cg.jcat.api.entity.Answer;
import com.cg.jcat.api.entity.Application;
import com.cg.jcat.api.exception.CountMissMatchException;
import com.cg.jcat.api.exception.OptionTextNotNullException;
import com.cg.jcat.api.exception.SystemExceptions;
import com.cg.jcat.api.dao.AnswerModel;

@Component
public class AssessmentService implements IAssessmentService {
	
	private static final Logger logger = LoggerFactory.getLogger(AssessmentDao.class);

	@Autowired
	AssessmentDao assessmentDao;

	@Autowired
	DTCloudableRuleDao dtCloudableRuleDao;

	@Autowired
	DTMigrationRuleDao dtMigrationRuleDao;

	@Autowired
	DTProviderRuleDao dtProviderRuleDao;

	Date date = new Date();

	@Override
	public List<AnswerModel> getAnswers(int applicationId) {
		return assessmentDao.getAnswers(applicationId);
	}

	@Override
	public boolean saveAnswers(List<AnswerModel> answerModels, int applicationId)
			throws SystemExceptions, OptionTextNotNullException {
		boolean afterSavedValue = false;
		StringBuffer strBuff = new StringBuffer();
		for (AnswerModel answerModel : answerModels) {
			if (StringUtils.isEmpty(answerModel.getOptionTextsEN())) {
				strBuff.append("Option text for question " + answerModel.getQuestionId() + " is empty!\n");
				throw new OptionTextNotNullException(strBuff.toString());
			} else {
				String optionText[] = answerModel.getOptionTextsEN().split(",");
				String optionIds[] = answerModel.getOptionIds().split(",");
				if (optionText.length != optionIds.length) {
					strBuff.append("Number of options for question " + answerModel.getQuestionId()
							+ " does not macthes with number of option text!\n");
				}
			}
		}
		afterSavedValue = assessmentDao.saveAnswers(answerModels, applicationId);
		return afterSavedValue;
	}

	@Override
	public void finalized(List<AnswerModel> answerModels, int applicationId, int stage)
			throws SystemExceptions, OptionTextNotNullException {
		saveAnswers(answerModels, applicationId);

		switch (stage) {
		case 1:
			stage1(applicationId);
			break;

		case 2:
			stage2(applicationId);
			break;

		default:
		}
	}

	private void stage1(int applicationId) {
		cloudableCheck(applicationId);
	}

	private void stage2(int applicationId) {
		Application application = assessmentDao.getApplicationByApplicationId(applicationId);
		migrationCheck(application);
		cloudProviderCheck(application);
		application.setAssessmentStage(2);
		application.setAssessmentCompleted(true);
		application.setAssessmentCompletionTime(date);
		assessmentDao.saveApp(application);
	}

	public boolean cloudableCheck(int applicationId) {
		int cloudableRuleFlag = 0;
		Application application = assessmentDao.getApplicationByApplicationId(applicationId);
		application.setAssessmentStage(1);

		List<DTCloudableRuleModel> cloudableRuleList = dtCloudableRuleDao.getCloudableRule();
		List<Answer> answersList = assessmentDao.getAnswersByApplicationId(applicationId);

		for (DTCloudableRuleModel cloudableRule : cloudableRuleList) {

			String[] cloudableRuleArray = cloudableRule.getOptionIds().split(",");
			for (Answer answers : answersList) {
				String[] answerOptionIdsArray = answers.getOptionIds().split(",");

				if (cloudableRule.getQuestionId() == (answers.getQuestionId())
						&& Arrays.equals(cloudableRuleArray, answerOptionIdsArray)) {
					assessmentDao.setCloudableInAns(answers.getAnswerId());
					cloudableRuleFlag++;
				}
			}
		}
		if (cloudableRuleFlag == cloudableRuleList.size()) {
			application.setDTCloudable(true);
			assessmentDao.saveApp(application);
			return true;
		} else {
			application.setDTCloudable(false);
			assessmentDao.saveApp(application);
			return false;
		}

	}

	public void migrationCheck(Application application) {
		List<Answer> allanswers = assessmentDao.getAnswersByApplicationId(application.getAid());
		for (DTMigrationModel migrationDAO : dtMigrationRuleDao.getMigrationPattern()) {
			int count = 0;
			HashSet numberOfRules = new HashSet();
			for (DTMigrationRuleModel migrationRuleDAO : dtMigrationRuleDao
					.getMigrationRule(migrationDAO.getMigrationId())) {
				for (Answer answers : allanswers) {
					if (answers.getQuestionId() == migrationRuleDAO.getQuestionId()) {

						numberOfRules.add(migrationRuleDAO.getQuestionId());
						String[] migrationRuleIdsArray = migrationRuleDAO.getRuleOptionIds().split(",");
						String[] answerOptionIdsArray = answers.getOptionIds().split(",");
						if (Arrays.equals(migrationRuleIdsArray, answerOptionIdsArray)) {
							assessmentDao.setMigrationInAnswerInAns(answers.getAnswerId());
							count++;
						}
					}
				}
			}
			if (migrationDAO.getLogicalOperator().equalsIgnoreCase("AND") && (count == numberOfRules.size())) {
				application.setAssessmentStage(2);
				application.setDtMigrationPattern(migrationDAO.getMigration_pattern());
				assessmentDao.saveApp(application);
				break;
			}
			if (migrationDAO.getLogicalOperator().equalsIgnoreCase("OR") && count >= 1) {
				application.setDtMigrationPattern(migrationDAO.getMigration_pattern());
				assessmentDao.saveApp(application);
				break;
			}
			if (migrationDAO.getLogicalOperator().equalsIgnoreCase("Others")) {
				application.setDtMigrationPattern(migrationDAO.getMigration_pattern());
				assessmentDao.saveApp(application);
				break;
			}

		}
	}

	public void cloudProviderCheck(Application application) {

		List<Answer> allanswers = assessmentDao.getAnswersByApplicationId(application.getAid());

		for (DTProvidersModel cloudProvider : dtProviderRuleDao.getCloudProvider()) {
			int count = 0, numberOfRules = 0;
			for (DTProviderRuleModel cloudProviderRuleDAO : dtProviderRuleDao
					.getCloudProviderRules(cloudProvider.getProviderId())) {
				for (Answer answers : allanswers) {
					if (answers.getQuestionId() == cloudProviderRuleDAO.getQuestionId()) {
						String[] cloudProviderRuleArray = cloudProviderRuleDAO.getRuleOptionIds().split(",");
						String[] answerOptionIdsArray = answers.getOptionIds().split(",");
						numberOfRules++;
						if (Arrays.equals(cloudProviderRuleArray, answerOptionIdsArray)) {
							assessmentDao.setCloudProviderInAnswer(answers.getAnswerId());
							count++;
						}
					}
				}
			}
			if ("OR".equalsIgnoreCase(cloudProvider.getLogicalOperator()) && count > 0) {
				assessmentDao.setCloudprovider(application, cloudProvider.getProviderName());
				break;
			}
			if (numberOfRules == count) {
				assessmentDao.setCloudprovider(application, cloudProvider.getProviderName());
				break;
			}
		}

	}

}
