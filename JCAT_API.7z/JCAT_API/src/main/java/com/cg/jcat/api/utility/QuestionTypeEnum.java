package com.cg.jcat.api.utility;

public enum QuestionTypeEnum {

	MULTIPLE_CHOICE_SINGLE_ANSWER,
	MULTIPLE_CHOICE_MULTIPLE_ANSWER,
	SHORT_ANSWER,
	LONG_ANSWER;
}
