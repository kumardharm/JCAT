package com.cg.jcat.api.dao;

import org.springframework.stereotype.Component;

@Component
public class BaseDao {

}
