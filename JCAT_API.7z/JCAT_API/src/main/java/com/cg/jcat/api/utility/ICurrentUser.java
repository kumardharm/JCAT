package com.cg.jcat.api.utility;

public interface ICurrentUser {
	
	public void setCurrentUser(String currentUser);
	String getCurrentUser ();

}
