package com.cg.jcat.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.jcat.api.entity.DTProviders;

public interface IDTProviderRepository extends JpaRepository<DTProviders, Integer>{

}
