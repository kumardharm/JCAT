package com.cg.jcat.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.jcat.api.entity.DTProviderRuleHistory;

public interface IDTProviderRuleHistory extends JpaRepository<DTProviderRuleHistory, Integer>{

}
