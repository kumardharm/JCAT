package com.cg.jcat.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.jcat.api.entity.DTMigrationRuleHistory;

public interface IDTMigrationRuleHistoryRepository extends JpaRepository<DTMigrationRuleHistory, Integer>{

}
