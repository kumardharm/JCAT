package com.cg.jcat.api.service;

import org.springframework.stereotype.Service;

@Service
public interface IBaseService {

}
